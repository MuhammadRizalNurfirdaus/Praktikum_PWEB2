<?php
include "classPelajar.php";
$siswa = new Pelajar("Muhammad Rizal Nurfirdaus", "Laki-laki", "20 Tahun", "20230810088", "Universitas Kuningan", 95);
$siswa->Tampil();
