<?php
include "classManusia.php";
$rizal = new Manusia("Muhammad Rizal Nurfirdaus");
echo "Nama: " . $dika->tampilkanNama() . "<br>";
$rizal->makan();
