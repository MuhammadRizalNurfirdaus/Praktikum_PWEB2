<?php
include "classMawarPutih.php";

$mawar = new MawarPutih("Semak", "Berduri", "Wangi");
$mawar->tampil();
?>