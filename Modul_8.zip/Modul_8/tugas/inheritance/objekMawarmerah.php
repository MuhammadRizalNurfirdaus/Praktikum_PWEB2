<?php
include "classMawarMerah.php";

$mawar = new MawarMerah("Semak", "Berduri", "Wangi");
$mawar->tampil();
?>