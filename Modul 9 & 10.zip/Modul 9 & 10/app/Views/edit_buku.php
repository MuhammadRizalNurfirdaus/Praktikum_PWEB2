<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Ubah Data Buku</title>
</head>

<body>
    <h1>Form Ubah Data Buku</h1>

    <?php helper(['form', 'url']); ?>

    <!-- PASTIKAN KEY DI SINI JUGA HURUF KECIL -->
    <?= form_open(site_url('c_buku/updatedata/' . $datarecord['kd_buku'])) ?>
    <table>
        <tr>
            <td>Kode Buku</td>
            <!-- GUNAKAN KEY HURUF KECIL -->
            <td>: <b><?= esc($datarecord['kd_buku']) ?></b> (Tidak bisa diubah)</td>
        </tr>
        <tr>
            <td>Judul Buku</td>
            <!-- GUNAKAN KEY HURUF KECIL -->
            <td>: <input type="text" name="judul_buku" value="<?= esc($datarecord['judul']) ?>" size="50" required></td>
        </tr>
        <tr>
            <td>Pengarang</td>
            <!-- GUNAKAN KEY HURUF KECIL -->
            <td>: <input type="text" name="pengarang_buku" value="<?= esc($datarecord['pengarang']) ?>" size="50" required></td>
        </tr>
        <tr>
            <td>Penerbit</td>
            <!-- GUNAKAN KEY HURUF KECIL -->
            <td>: <input type="text" name="penerbit_buku" value="<?= esc($datarecord['penerbit']) ?>" size="50" required></td>
        </tr>
        <tr>
            <td></td>
            <td>  <input type="submit" value="UPDATE"> <a href="<?= site_url('c_buku') ?>"><button type="button">Batal</button></a></td>
        </tr>
    </table>
    <?= form_close() ?>
</body>

</html>